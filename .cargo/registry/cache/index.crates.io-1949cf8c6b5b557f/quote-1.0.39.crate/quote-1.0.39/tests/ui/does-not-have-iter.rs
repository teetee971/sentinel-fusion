use quote::quote;

fn main() {
    quote!(#(a b)*);
}
