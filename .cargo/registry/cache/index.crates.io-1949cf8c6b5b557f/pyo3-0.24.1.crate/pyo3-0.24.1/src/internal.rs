//! Holding place for code which is not intended to be reachable from outside of PyO3.

pub(crate) mod get_slot;
